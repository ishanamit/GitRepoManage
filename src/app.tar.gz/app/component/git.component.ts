import { Component } from '@angular/core';

import { GitService } from '../services/git.services';

@Component({
  selector: 'my-github',
  templateUrl: './git.component.html',
  styleUrls: ['./git.component.css'],
  providers: [ GitService ],
})
export class GitComponent {
    user:any;
    repos:any;
    username: string;

    constructor(private _gitservice: GitService){}


    
    search(){
        this._gitservice.updateusername(this.username);

        //console.log(this.username);
        this._gitservice.getUser().subscribe(user => {
            //console.log(user);
            this.user = user; 
        });

        this._gitservice.getRepos().subscribe(repos => {
            //console.log(repos);
            this.repos = repos; 
        });
    }
    

}