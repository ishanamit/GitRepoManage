import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule} from '@angular/http';
import { FormsModule } from '@angular/forms';


import { AppComponent } from './app.component';


import { GitComponent } from './component/git.component';
import { GitService } from './services/git.services';


@NgModule({
  declarations: [
    AppComponent,
    GitComponent,
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
  ],
  providers: [GitService],
  bootstrap: [AppComponent]
})
export class AppModule { }